var searchData=
[
  ['setdetectconfig',['SetDetectConfig',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a2a02ef224d07da6eadd59bca70e17bdf',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['setimagedata',['SetImageData',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#aaea1483d888a49599be430406ea1b800',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['shutdown',['ShutDown',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a2cebfbb2b3e714afc92d1005f3f13ef9',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]]
];
