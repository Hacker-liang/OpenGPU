var searchData=
[
  ['mg_5fint8',['MG_INT8',['../_m_g___common_8h.html#a2f1a55c439a0c5cb0ba04b78d3f72fe9',1,'MG_Common.h']]]
];
