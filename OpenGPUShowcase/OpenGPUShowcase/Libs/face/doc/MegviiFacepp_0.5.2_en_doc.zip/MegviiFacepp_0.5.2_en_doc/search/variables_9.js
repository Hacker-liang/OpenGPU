var searchData=
[
  ['male',['male',['../struct_m_g___g_e_n_d_e_r.html#a5e590abc870bd200985d5f635f9b8187',1,'MG_GENDER']]],
  ['mg_5ffacepp',['mg_facepp',['../_m_g___facepp_8h.html#a1b302eb1efa03eef5cf917858d844f1b',1,'MG_Facepp.h']]],
  ['min_5fface_5fsize',['min_face_size',['../struct_m_g___f_p_p___a_p_i_c_o_n_f_i_g.html#ae10b49c357efffd6a8d36cb7ad59c129',1,'MG_FPP_APICONFIG']]],
  ['minority',['minority',['../struct_m_g___f_a_c_e.html#a6f06b722a0a917a63cf8f2b0c2ee8765',1,'MG_FACE']]],
  ['moutstatus',['moutstatus',['../struct_m_g___f_a_c_e.html#a6dd8696e698351c35ebaa0a237f8da62',1,'MG_FACE']]]
];
