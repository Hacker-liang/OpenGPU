var searchData=
[
  ['mg_5ffpp_5fattr_5fage_5fgender',['MG_FPP_ATTR_AGE_GENDER',['../_m_g___facepp_8h.html#ab87c963a7a5099c651360c2f3ef98b94',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fattr_5fblurness',['MG_FPP_ATTR_BLURNESS',['../_m_g___facepp_8h.html#aea2c1b7263272d132dd86f0fcbbb7087',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fattr_5fextract_5ffeature',['MG_FPP_ATTR_EXTRACT_FEATURE',['../_m_g___facepp_8h.html#a5a2d47e662ebefa464e89655d15a92f2',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fattr_5feyestatus',['MG_FPP_ATTR_EYESTATUS',['../_m_g___facepp_8h.html#a97f88e1cb9006efe14d79b6ceecb722a',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fattr_5fminority',['MG_FPP_ATTR_MINORITY',['../_m_g___facepp_8h.html#a7f706d22343a005a2f0eea547bcfb442',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fattr_5fmouthstatus',['MG_FPP_ATTR_MOUTHSTATUS',['../_m_g___facepp_8h.html#ad2e8c192de8fe683aef6fa5424d16489',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fattr_5fpose3d',['MG_FPP_ATTR_POSE3D',['../_m_g___facepp_8h.html#a986f84257e91d82e47eaccdf89e3f7ed',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fdetect',['MG_FPP_DETECT',['../_m_g___facepp_8h.html#aae9df9924a4b5755fa8d85f2953ea77a',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fget_5flandmark101',['MG_FPP_GET_LANDMARK101',['../_m_g___facepp_8h.html#a16e874b4cc68d6d7bba481e7ca91f666',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fget_5flandmark106',['MG_FPP_GET_LANDMARK106',['../_m_g___facepp_8h.html#aa499db2752b965442f8f761e7eccd641',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fget_5flandmark81',['MG_FPP_GET_LANDMARK81',['../_m_g___facepp_8h.html#a3a95129fba51e257b2e3638ff03762bc',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fget_5flandmark84',['MG_FPP_GET_LANDMARK84',['../_m_g___facepp_8h.html#a52186359e6e3c8f2c796659c0ce7f1ac',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5ftrack',['MG_FPP_TRACK',['../_m_g___facepp_8h.html#a5fff9edb2bdf0d7f74b08ba5b098f717',1,'MG_Facepp.h']]],
  ['mg_5flandmark_5fnr',['MG_LANDMARK_NR',['../_m_g___common_8h.html#ab08016a1354ce3e4cc1a63b0ca4c7bb5',1,'MG_Common.h']]],
  ['mg_5fleft_5feye_5fpupil',['MG_LEFT_EYE_PUPIL',['../_m_g___common_8h.html#a4eea1fcf509ce5a84a50a3802ab4e46f',1,'MG_Common.h']]]
];
