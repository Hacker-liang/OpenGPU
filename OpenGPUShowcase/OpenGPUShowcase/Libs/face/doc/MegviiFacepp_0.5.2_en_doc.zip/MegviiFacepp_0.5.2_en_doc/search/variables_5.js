var searchData=
[
  ['face_5fconfidence_5ffilter',['face_confidence_filter',['../struct_m_g___f_p_p___a_p_i_c_o_n_f_i_g.html#ab0b8a988c47c29a0d20e7a32427316b8',1,'MG_FPP_APICONFIG']]],
  ['facecompare',['FaceCompare',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#ad4dfe5f8f35f050cf21d003644c3826b',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['female',['female',['../struct_m_g___g_e_n_d_e_r.html#af2af039fb84764abb99ff7d2cd31af05',1,'MG_GENDER']]]
];
