var indexSectionsWithContent =
{
  0: "abcdefgilmoprstxy",
  1: "m",
  2: "m",
  3: "abcdefgilmoprstxy",
  4: "m",
  5: "m",
  6: "m",
  7: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

