var searchData=
[
  ['interval',['interval',['../struct_m_g___f_p_p___a_p_i_c_o_n_f_i_g.html#ad692e64016f93f8a1ec7dd68e40518ab',1,'MG_FPP_APICONFIG']]]
];
