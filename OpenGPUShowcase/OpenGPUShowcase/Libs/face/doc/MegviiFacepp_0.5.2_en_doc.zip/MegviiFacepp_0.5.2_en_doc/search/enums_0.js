var searchData=
[
  ['mg_5feyestatus',['MG_EYESTATUS',['../_m_g___common_8h.html#a4aa0d12dd778dc35ae641fae82bba709',1,'MG_Common.h']]],
  ['mg_5ffpp_5fdetectionmode',['MG_FPP_DETECTIONMODE',['../_m_g___facepp_8h.html#aaec1d1d953deb8521af35bd18b8a811e',1,'MG_Facepp.h']]],
  ['mg_5fimagemode',['MG_IMAGEMODE',['../_m_g___common_8h.html#a27c660892b89a8f3b21116d59164d792',1,'MG_Common.h']]],
  ['mg_5fmouthstatus',['MG_MOUTHSTATUS',['../_m_g___common_8h.html#afb9b4e071d6e3a778e82fd24ee21c02b',1,'MG_Common.h']]],
  ['mg_5forientation',['MG_Orientation',['../_m_g___common_8h.html#ac76255f4158ecd6b18aad652980c872b',1,'MG_Common.h']]],
  ['mg_5fretcode',['MG_RETCODE',['../_m_g___common_8h.html#a38fecb61b8c39592ddb51f75d4a5c5e7',1,'MG_Common.h']]],
  ['mg_5frotation',['MG_ROTATION',['../_m_g___common_8h.html#a27584d1560c93f298ef1352995bc6590',1,'MG_Common.h']]],
  ['mg_5fsdkauthtype',['MG_SDKAUTHTYPE',['../_m_g___common_8h.html#a3ee48a4a8bc6440c8f21fae5dfcded4c',1,'MG_Common.h']]]
];
