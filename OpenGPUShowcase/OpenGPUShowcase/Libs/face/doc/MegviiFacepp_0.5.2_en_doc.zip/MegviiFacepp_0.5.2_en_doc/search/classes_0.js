var searchData=
[
  ['mg_5f3dpose',['MG_3DPOSE',['../struct_m_g__3_d_p_o_s_e.html',1,'']]],
  ['mg_5fability',['MG_ABILITY',['../struct_m_g___a_b_i_l_i_t_y.html',1,'']]],
  ['mg_5falgorithminfo',['MG_ALGORITHMINFO',['../struct_m_g___a_l_g_o_r_i_t_h_m_i_n_f_o.html',1,'']]],
  ['mg_5fface',['MG_FACE',['../struct_m_g___f_a_c_e.html',1,'']]],
  ['mg_5ffacelandmarks',['MG_FACELANDMARKS',['../struct_m_g___f_a_c_e_l_a_n_d_m_a_r_k_s.html',1,'']]],
  ['mg_5ffacepp_5fapi_5ffunctions_5ftype',['MG_FACEPP_API_FUNCTIONS_TYPE',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html',1,'']]],
  ['mg_5ffpp_5fapiconfig',['MG_FPP_APICONFIG',['../struct_m_g___f_p_p___a_p_i_c_o_n_f_i_g.html',1,'']]],
  ['mg_5fgender',['MG_GENDER',['../struct_m_g___g_e_n_d_e_r.html',1,'']]],
  ['mg_5fpoint',['MG_POINT',['../struct_m_g___p_o_i_n_t.html',1,'']]],
  ['mg_5frectangle',['MG_RECTANGLE',['../struct_m_g___r_e_c_t_a_n_g_l_e.html',1,'']]]
];
