var searchData=
[
  ['rect',['rect',['../struct_m_g___f_a_c_e.html#ac6790410b21dead51c8c87924df5ca7e',1,'MG_FACE']]],
  ['releaseapihandle',['ReleaseApiHandle',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#aff5d16c86e8aa3351cc29ca77c0ad56a',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['releaseimagehandle',['ReleaseImageHandle',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#aaadd12cc76f4cf18ed48a5f9f3bc8bfc',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['resettrack',['ResetTrack',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a53c43385e1f5bcc26e8125a382c2a167',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['right',['right',['../struct_m_g___r_e_c_t_a_n_g_l_e.html#af98bc1a68ec2b86b8b0dee733175801d',1,'MG_RECTANGLE']]],
  ['right_5feyestatus',['right_eyestatus',['../struct_m_g___f_a_c_e.html#a3e138a0223d38abf7584027ad6f1a33b',1,'MG_FACE']]],
  ['roi',['roi',['../struct_m_g___f_p_p___a_p_i_c_o_n_f_i_g.html#aac46c1afd3c12df2c30b29028554a72e',1,'MG_FPP_APICONFIG']]],
  ['roll',['roll',['../struct_m_g__3_d_p_o_s_e.html#ac2025acd9c519bc466e9d5bec7a7782a',1,'MG_3DPOSE']]],
  ['rotation',['rotation',['../struct_m_g___f_p_p___a_p_i_c_o_n_f_i_g.html#ad0896de3b631a7d8cf84fbfc8015d533',1,'MG_FPP_APICONFIG']]]
];
