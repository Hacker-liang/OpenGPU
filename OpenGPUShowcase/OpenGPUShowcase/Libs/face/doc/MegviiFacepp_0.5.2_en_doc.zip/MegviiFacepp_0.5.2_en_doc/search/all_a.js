var searchData=
[
  ['one_5fface_5ftracking',['one_face_tracking',['../struct_m_g___f_p_p___a_p_i_c_o_n_f_i_g.html#a3b3d578761f1689dcdf109ed7706ea62',1,'MG_FPP_APICONFIG']]]
];
