var searchData=
[
  ['blurness',['blurness',['../struct_m_g___f_a_c_e.html#a87b32a9b945bb6e710240d6dc23172e9',1,'MG_FACE']]],
  ['bottom',['bottom',['../struct_m_g___r_e_c_t_a_n_g_l_e.html#a6ca3c4b559186ca87d377f7247258605',1,'MG_RECTANGLE']]],
  ['bundleid',['bundleid',['../struct_m_g___a_l_g_o_r_i_t_h_m_i_n_f_o.html#a9915dccde061cc6e2764a1a42e7a23e6',1,'MG_ALGORITHMINFO']]]
];
