var searchData=
[
  ['gender',['gender',['../struct_m_g___f_a_c_e.html#a806bfdfc3668813603bee43a6955df99',1,'MG_FACE']]],
  ['getalgorithminfo',['GetAlgorithmInfo',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a13fb26a5883eef5e0b9d1f4a63741740',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getapiversion',['GetApiVersion',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a4cf47a795262d042f354d8ad821109e1',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getattribute',['GetAttribute',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a4ac56d3f28fcb18a97bbbf847d38b2d3',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getdetectconfig',['GetDetectConfig',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a1dc56210a071c3fa450ce279b36e80aa',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getfaceinfo',['GetFaceInfo',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#add105d08334445cdbe3804e14ed87fe3',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getfeaturedata',['GetFeatureData',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#aa8ba34245d853387adfd47b2e18484fc',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getjenkinsnumber',['GetJenkinsNumber',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a497695046f1a90d2a400809e0b0816cd',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getlandmark',['GetLandmark',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a116f91f24bb127f395deb45e9a4f4c73',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getrect',['GetRect',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a1c21a2f447a69abb3a99c73e82b27b10',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]]
];
