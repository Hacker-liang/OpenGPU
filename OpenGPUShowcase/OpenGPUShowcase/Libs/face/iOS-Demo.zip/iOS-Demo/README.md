# MegviiFacepp-iOS-SDK

An iOS wrapper of MegviiFacepp SDK (the mobile SDK).

版本号： 0.4.7（此版本 SDK 适用于 Megvii-Facepp 0.4.7I）

[学习如何使用 SDK](https://github.com/FacePlusPlus/MegviiFacepp-iOS-SDK/wiki/)

Version: 0.4.7 (This version is compatible to Megvii-Facepp 0.4.7I)

[Learn how to use SDK](https://github.com/FacePlusPlus/MegviiFacepp-iOS-SDK/wiki/)




