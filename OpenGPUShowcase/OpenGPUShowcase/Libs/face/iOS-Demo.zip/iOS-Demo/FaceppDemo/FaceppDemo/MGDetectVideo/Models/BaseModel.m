//
//  BaseModel.m
//  KoalaPhoto
//
//  Created by 张英堂 on 14/12/22.
//  Copyright (c) 2014年 visionhacker. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel



@end
