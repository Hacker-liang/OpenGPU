//
//  MGVideoTestVC.h
//  FaceppDemo
//
//  Created by Megvii on 2017/7/20.
//  Copyright © 2017年 megvii. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGVideoTestVC : UIViewController

@end
