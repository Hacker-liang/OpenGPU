//
//  BaseCell.m
//  KoalaPhoto
//
//  Created by 张英堂 on 14/12/22.
//  Copyright (c) 2014年 visionhacker. All rights reserved.
//

#import "BaseCell.h"

@implementation BaseCell


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



+ (CGFloat)cellHigth{
    return 44.0f;
}

@end
