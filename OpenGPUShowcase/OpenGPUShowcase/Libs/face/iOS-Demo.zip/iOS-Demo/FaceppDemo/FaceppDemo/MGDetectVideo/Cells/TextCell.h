//
//  TextCell.h
//  MGSDKV2Test
//
//  Created by 张英堂 on 2016/10/21.
//  Copyright © 2016年 megvii. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TextModel.h"
#import "BaseCell.h"

@interface TextCell : BaseCell

@property (nonatomic, strong) TextModel *model;


//- (CGFloat)CellHight;



@end
