//
//  MGNetAccount_example.h
//  FaceppDemo
//
//  Created by 张英堂 on 2017/1/12.
//  Copyright © 2017年 megvii. All rights reserved.
//

#ifndef MGNetAccount_example_h
#define MGNetAccount_example_h



// 访问 https://www.faceplusplus.com.cn， 登录后在控制台生成对应的 key 和 secret 填写到下面的字符串中

#define MG_LICENSE_KEY      @"" // api_key
#define MG_LICENSE_SECRET    @"" // api_secret


#endif /* MGNetAccount_example_h */
