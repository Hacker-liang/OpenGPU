//
//  MGMarkSetViewController.h
//  LandMask
//
//  Created by 张英堂 on 16/8/17.
//  Copyright © 2016年 megvii. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGMarkSetViewController : UIViewController

@end
