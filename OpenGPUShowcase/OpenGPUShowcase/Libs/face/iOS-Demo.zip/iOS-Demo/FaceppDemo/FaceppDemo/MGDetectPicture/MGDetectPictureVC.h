//
//  MGDetectPictureVC.h
//  FaceppDemo
//
//  Created by 张英堂 on 2016/11/8.
//  Copyright © 2016年 megvii. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGDetectPictureVC : UIViewController

@end
