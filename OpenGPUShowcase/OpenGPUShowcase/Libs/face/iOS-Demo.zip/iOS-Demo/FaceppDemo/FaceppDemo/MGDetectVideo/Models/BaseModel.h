//
//  BaseModel.h
//  KoalaPhoto
//
//  Created by 张英堂 on 14/12/22.
//  Copyright (c) 2014年 visionhacker. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface BaseModel : NSObject



@end
