//
//  MGDetectRect.m
//  MGFacepp
//
//  Created by Megvii on 2017/10/18.
//  Copyright © 2017年 megvii. All rights reserved.
//

#import "MGDetectRectInfo.h"

@implementation MGDetectRectInfo

@end
